#!/system/bin/sh

mount --bind /data/adb/ksu/bin /data/adb/magisk